package com.vehicle.domain.vehicles;

//This enum holds the type of the vehicle - TRCUK, VAN, SEMI
public enum VehicleType {
	
	TRCUK, VAN, SEMI

}
