/**
 * 
 */
package com.vehicle.domain;


public interface DomainObject {
	
	 Integer getId();

	 void setId(Integer id);

}
